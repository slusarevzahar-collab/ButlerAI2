import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface Tab {
  id: string;
  label: string;
  content: React.ReactNode;
  badge?: number;
}

interface SwipeableTabsProps {
  tabs: Tab[];
  defaultTab?: string;
  onTabChange?: (tabId: string) => void;
  showTabHeaders?: boolean;
  onDragUpdate?: (dragOffset: number, isDragging: boolean) => void;
}

export function SwipeableTabs({ tabs, defaultTab, onTabChange, showTabHeaders = true, onDragUpdate }: SwipeableTabsProps) {
  const [activeTab, setActiveTab] = useState(defaultTab || tabs[0]?.id || '');
  const [touchStart, setTouchStart] = useState<{ x: number; y: number } | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState(0);
  const [swipeDirection, setSwipeDirection] = useState<'horizontal' | 'vertical' | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const activeIndex = tabs.findIndex(tab => tab.id === activeTab);
  const safeIndex = activeIndex >= 0 ? activeIndex : 0;

  // Sync with external defaultTab changes
  React.useEffect(() => {
    if (defaultTab && defaultTab !== activeTab) {
      setActiveTab(defaultTab);
    }
  }, [defaultTab]);

  if (!tabs || tabs.length === 0) {
    return <div>Loading...</div>;
  }

  const handleTabChange = (tabId: string) => {
    if (tabId !== activeTab) {
      setActiveTab(tabId);
      if (onTabChange) {
        onTabChange(tabId);
      }
    }
  };

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchStart({
      x: e.targetTouches[0].clientX,
      y: e.targetTouches[0].clientY
    });
    setSwipeDirection(null);
    setIsDragging(false);
    setDragOffset(0);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (!touchStart || !containerRef.current) return;
    
    const currentTouch = {
      x: e.targetTouches[0].clientX,
      y: e.targetTouches[0].clientY
    };
    
    const diffX = currentTouch.x - touchStart.x;
    const diffY = currentTouch.y - touchStart.y;
    
    // Determine swipe direction on first significant move (reduced threshold to 5px)
    if (!swipeDirection && (Math.abs(diffX) > 5 || Math.abs(diffY) > 5)) {
      if (Math.abs(diffX) > Math.abs(diffY)) {
        setSwipeDirection('horizontal');
        setIsDragging(true);
      } else {
        setSwipeDirection('vertical');
      }
    }
    
    // Only handle horizontal swipes for tab switching
    if (swipeDirection === 'vertical') return;
    
    // Handle horizontal swipe
    if (swipeDirection === 'horizontal') {
      // Prevent default scroll behavior for horizontal swipe
      e.preventDefault();
      
      const containerWidth = containerRef.current.offsetWidth;
      
      // Normalize the drag offset to -1 to 1 range
      let normalizedOffset = diffX / containerWidth;
      
      // Prevent dragging beyond boundaries with resistance
      if ((safeIndex === 0 && normalizedOffset > 0) || 
          (safeIndex === tabs.length - 1 && normalizedOffset < 0)) {
        normalizedOffset = normalizedOffset * 0.3; // Rubber band at boundaries
      }
      
      setDragOffset(normalizedOffset);
      
      // Notify parent about drag
      if (onDragUpdate) {
        onDragUpdate(normalizedOffset, true);
      }
    }
  };

  const onTouchEnd = () => {
    if (!isDragging || swipeDirection !== 'horizontal') {
      // Reset state
      setTouchStart(null);
      setSwipeDirection(null);
      setIsDragging(false);
      setDragOffset(0);
      if (onDragUpdate) {
        onDragUpdate(0, false);
      }
      return;
    }
    
    const threshold = 0.25; // 25% swipe to trigger tab change (reduced from 50%)
    
    let shouldChangeTab = false;
    
    // Swipe left (next tab)
    if (dragOffset < -threshold && safeIndex < tabs.length - 1) {
      handleTabChange(tabs[safeIndex + 1].id);
      shouldChangeTab = true;
    } 
    // Swipe right (previous tab)
    else if (dragOffset > threshold && safeIndex > 0) {
      handleTabChange(tabs[safeIndex - 1].id);
      shouldChangeTab = true;
    }
    
    // Reset
    setIsDragging(false);
    setSwipeDirection(null);
    setTouchStart(null);
    
    // Notify parent that dragging ended
    if (onDragUpdate) {
      onDragUpdate(0, false);
    }
    
    // If we're not changing tabs, animate back to 0
    if (!shouldChangeTab) {
      setDragOffset(0);
    } else {
      // Small delay to allow tab change animation
      setTimeout(() => setDragOffset(0), 50);
    }
  };

  // Calculate content position based on drag
  const getContentOffset = () => {
    return dragOffset * 100;
  };

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* Tab Headers */}
      {showTabHeaders && (
        <div className="flex px-2 xs:px-4 sm:px-6 relative">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleTabChange(tab.id)}
              className={`flex-1 px-1 xs:px-2 sm:px-4 py-3 relative transition-all duration-300 flex items-center justify-center min-w-0 ${
                activeTab === tab.id ? 'text-foreground font-semibold' : 'text-muted-foreground'
              }`}
            >
              <span className="relative z-10 flex items-center justify-center max-w-full text-sm sm:text-base gap-0.5 xs:gap-1">
                <span className="truncate">{tab.label}</span>
                {tab.badge !== undefined && <span className="text-xs opacity-60 flex-shrink-0">({tab.badge})</span>}
              </span>
            </button>
          ))}
          
          {/* Animated Indicator - follows finger during drag */}
          <motion.div
            className="absolute bottom-0 h-0.5 sm:h-1 bg-primary rounded-t-full"
            animate={{
              left: `${((safeIndex + dragOffset) / tabs.length) * 100}%`,
              width: `${100 / tabs.length}%`
            }}
            transition={{
              type: 'tween',
              duration: isDragging ? 0 : 0.3,
              ease: 'easeOut'
            }}
          />
        </div>
      )}

      {/* Tab Content with Slide Animation */}
      <div 
        ref={containerRef}
        className="flex-1 overflow-hidden relative"
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        style={{ touchAction: swipeDirection === 'horizontal' ? 'none' : 'auto' }}
      >
        {isDragging && swipeDirection === 'horizontal' ? (
          // During drag: show current and adjacent tabs
          <>
            {/* Current tab */}
            <div 
              className="absolute inset-0 overflow-y-auto"
              style={{ 
                transform: `translateX(${getContentOffset()}%)`,
                transition: 'none',
                pointerEvents: 'none'
              }}
            >
              {tabs[safeIndex]?.content}
            </div>
            
            {/* Next tab (when swiping left) */}
            {safeIndex < tabs.length - 1 && dragOffset < -0.02 && (
              <div 
                className="absolute inset-0 overflow-y-auto pointer-events-none"
                style={{ 
                  transform: `translateX(${100 + getContentOffset()}%)`,
                  transition: 'none'
                }}
              >
                {tabs[safeIndex + 1]?.content}
              </div>
            )}
            
            {/* Previous tab (when swiping right) */}
            {safeIndex > 0 && dragOffset > 0.02 && (
              <div 
                className="absolute inset-0 overflow-y-auto pointer-events-none"
                style={{ 
                  transform: `translateX(${-100 + getContentOffset()}%)`,
                  transition: 'none'
                }}
              >
                {tabs[safeIndex - 1]?.content}
              </div>
            )}
          </>
        ) : (
          // Not dragging: show only current tab with smooth transition
          <motion.div 
            key={activeTab}
            className="absolute inset-0 overflow-y-auto"
            initial={false}
            animate={{ 
              x: `${dragOffset * 100}%`,
              opacity: 1
            }}
            transition={{ 
              type: 'spring',
              stiffness: 300,
              damping: 30,
              duration: 0.25
            }}
          >
            {tabs[safeIndex]?.content}
          </motion.div>
        )}
      </div>
    </div>
  );
}
