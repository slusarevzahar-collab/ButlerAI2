import { useState, useRef } from 'react';
import { Guest } from '../App';
import { Plus, ChevronRight, ChevronLeft, Search, X } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useLanguage } from './LanguageProvider';
import { GuestCard } from './GuestCard';
import { motion, AnimatePresence } from 'motion/react';

interface GuestsViewProps {
  guests: Guest[];
  onUpdateGuestStatus?: (guestId: string, status: Guest['status']) => void;
  onUpdateGuestTransportation?: (guestId: string, transportation: Guest['transportation']) => void;
  onUpdateGuest?: (guestId: string, updates: Partial<Guest>) => void;
  onAddGuest?: () => void;
}

export function GuestsView({ guests, onUpdateGuestStatus, onUpdateGuestTransportation, onUpdateGuest, onAddGuest }: GuestsViewProps) {
  const { t } = useLanguage();
  const [expandedGuestId, setExpandedGuestId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'in-house' | 'waiting'>('in-house');
  const [showDepartedView, setShowDepartedView] = useState(false);
  const [showSearchDialog, setShowSearchDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);
  
  // Swipe state
  const [dragOffset, setDragOffset] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [swipeDirection, setSwipeDirection] = useState<'horizontal' | 'vertical' | null>(null);
  const dragStartX = useRef(0);
  const dragStartY = useRef(0);
  const dragStartTime = useRef(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleExpandChange = (guestId: string, expanded: boolean) => {
    if (expanded) {
      setExpandedGuestId(guestId);
    } else {
      setExpandedGuestId(null);
    }
  };

  // Filter guests
  const filterGuestsByStatus = (status: 'in-house' | 'waiting' | 'departed') => {
    return guests.filter(guest => {
      if (status === 'in-house') return guest.status === 'checked-in';
      if (status === 'waiting') return guest.status === 'waiting';
      if (status === 'departed') return guest.status === 'departed';
      return false;
    });
  };

  const inHouseGuests = filterGuestsByStatus('in-house');
  const waitingGuests = filterGuestsByStatus('waiting');
  const departedGuests = filterGuestsByStatus('departed');
  
  // Filter by search query
  const filterBySearch = (guestList: Guest[]) => {
    if (!searchQuery.trim()) return guestList;
    const query = searchQuery.toLowerCase();
    return guestList.filter(guest => 
      guest.name.toLowerCase().includes(query) ||
      guest.room.toLowerCase().includes(query)
    );
  };
  
  const currentGuests = filterBySearch(
    showDepartedView ? departedGuests :
    activeTab === 'in-house' ? inHouseGuests : 
    waitingGuests
  );
  
  // Handle search open/close
  const handleSearchOpen = () => {
    setShowSearchDialog(true);
    // Focus input after animation
    setTimeout(() => {
      searchInputRef.current?.focus();
    }, 200);
  };
  
  const handleSearchClose = () => {
    setShowSearchDialog(false);
    setSearchQuery('');
  };

  // Swipe handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    dragStartX.current = e.touches[0].clientX;
    dragStartY.current = e.touches[0].clientY;
    dragStartTime.current = Date.now();
    setSwipeDirection(null);
    setIsDragging(false);
    setDragOffset(0);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const diffX = currentX - dragStartX.current;
    const diffY = currentY - dragStartY.current;
    
    // Determine swipe direction on first significant move (reduced threshold to 5px)
    if (!swipeDirection && (Math.abs(diffX) > 5 || Math.abs(diffY) > 5)) {
      if (Math.abs(diffX) > Math.abs(diffY)) {
        setSwipeDirection('horizontal');
        setIsDragging(true);
      } else {
        setSwipeDirection('vertical');
      }
    }
    
    // Only handle horizontal swipes for tab switching
    if (swipeDirection === 'vertical') return;
    
    // Handle horizontal swipe
    if (swipeDirection === 'horizontal') {
      // Prevent default scroll behavior for horizontal swipe
      e.preventDefault();
      
      const containerWidth = containerRef.current?.offsetWidth || window.innerWidth;
      
      // Calculate offset as percentage
      let offset = diffX / containerWidth;
      
      // Prevent swiping beyond bounds with rubber band effect
      if (activeTab === 'in-house' && offset > 0) {
        offset = offset * 0.3; // Rubber band effect at start
      } else if (activeTab === 'waiting' && offset < 0) {
        offset = offset * 0.3; // Rubber band effect at end
      }
      
      setDragOffset(offset);
    }
  };

  const handleTouchEnd = () => {
    // If no horizontal swipe was detected, just reset
    if (!isDragging || swipeDirection !== 'horizontal') {
      setSwipeDirection(null);
      setIsDragging(false);
      setDragOffset(0);
      return;
    }

    const swipeThreshold = 0.25; // 25% to trigger tab change
    const swipeVelocityThreshold = 0.3; // Lower velocity threshold
    const swipeDuration = Math.max(Date.now() - dragStartTime.current, 1);
    const swipeVelocity = Math.abs(dragOffset) / swipeDuration;

    let shouldChangeTab = false;

    // Determine if we should change tab based on distance or velocity
    if (Math.abs(dragOffset) > swipeThreshold || swipeVelocity > swipeVelocityThreshold) {
      if (dragOffset < -0.1 && activeTab === 'in-house') {
        // Swipe left: go to waiting
        setActiveTab('waiting');
        setExpandedGuestId(null);
        shouldChangeTab = true;
      } else if (dragOffset > 0.1 && activeTab === 'waiting') {
        // Swipe right: go to in-house
        setActiveTab('in-house');
        setExpandedGuestId(null);
        shouldChangeTab = true;
      }
    }

    // Reset drag state immediately
    setIsDragging(false);
    setSwipeDirection(null);
    
    // If we're not changing tabs, animate back to 0
    if (!shouldChangeTab) {
      setDragOffset(0);
    } else {
      // Small delay to allow tab change animation
      setTimeout(() => setDragOffset(0), 50);
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header with OneUI style - Always visible */}
      <motion.div 
        className="flex-shrink-0 bg-card relative z-10"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.15 }}
      >
        <div className="px-4 xs:px-5 sm:px-6 pt-6 xs:pt-7 sm:pt-8 pb-4">
          <div className="flex items-center justify-between gap-2">
            <AnimatePresence mode="wait">
              {!showSearchDialog ? (
                <motion.h1 
                  key="title"
                  className="text-foreground text-2xl xs:text-3xl truncate"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2 }}
                >
                  {t('guests')}
                </motion.h1>
              ) : (
                <motion.div 
                  key="search"
                  className="flex-1 relative"
                  initial={{ opacity: 0, width: 48 }}
                  animate={{ opacity: 1, width: '100%' }}
                  exit={{ opacity: 0, width: 48 }}
                  transition={{ duration: 0.25, ease: 'easeOut' }}
                >
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 xs:w-5 xs:h-5 text-muted-foreground pointer-events-none" />
                  <Input 
                    ref={searchInputRef}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={t('searchGuests')}
                    className="h-10 xs:h-11 sm:h-12 pl-10 pr-10 rounded-3xl border-input"
                  />
                  <button
                    onClick={handleSearchClose}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="w-4 h-4 xs:w-5 xs:h-5" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
            
            <div className="flex items-center gap-2">
              {!showSearchDialog && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.2 }}
                >
                  <Button 
                    size="sm" 
                    variant="ghost"
                    onClick={handleSearchOpen} 
                    className="h-10 xs:h-11 sm:h-12 w-10 xs:w-11 sm:w-12 p-0 rounded-3xl shadow-sm flex-shrink-0"
                  >
                    <Search className="w-4 h-4 xs:w-5 xs:h-5" />
                  </Button>
                </motion.div>
              )}
              <Button 
                size="sm" 
                onClick={onAddGuest} 
                className="h-10 xs:h-11 sm:h-12 px-4 xs:px-5 sm:px-6 rounded-3xl shadow-sm flex-shrink-0"
              >
                <Plus className="w-4 h-4 xs:w-5 xs:h-5 sm:mr-2" />
                <span className="hidden xs:inline">{t('addGuest')}</span>
              </Button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Tabs and Content - Sliding container */}
      <div className="flex-1 overflow-hidden relative">
        {/* Main Sheet - In-house and Waiting */}
        <div
          className="absolute inset-0 flex flex-col transition-transform duration-300 ease-out"
          style={{
            transform: showDepartedView ? 'translateX(-100%)' : 'translateX(0)'
          }}
        >
          {/* Tab Headers with Departed Button */}
          <div className="flex-shrink-0 border-b border-border bg-card">
            <div className="flex items-center relative">
              <div className="flex-1 flex px-2 xs:px-4 sm:px-6 relative">
                <button
                  onClick={() => {
                    setActiveTab('in-house');
                    setExpandedGuestId(null);
                  }}
                  className={`flex-1 px-1 xs:px-2 sm:px-4 py-3 relative transition-all duration-300 flex items-center justify-center min-w-0 ${
                    activeTab === 'in-house' ? 'text-foreground font-semibold' : 'text-muted-foreground'
                  }`}
                >
                  <span className="relative z-10 flex items-center justify-center max-w-full text-sm sm:text-base gap-0.5 xs:gap-1">
                    <span className="truncate">{t('checkedIn')}</span>
                    <span className="text-xs opacity-60 flex-shrink-0">({inHouseGuests.length})</span>
                  </span>
                </button>
                
                <button
                  onClick={() => {
                    setActiveTab('waiting');
                    setExpandedGuestId(null);
                  }}
                  className={`flex-1 px-1 xs:px-2 sm:px-4 py-3 relative transition-all duration-300 flex items-center justify-center min-w-0 ${
                    activeTab === 'waiting' ? 'text-foreground font-semibold' : 'text-muted-foreground'
                  }`}
                >
                  <span className="relative z-10 flex items-center justify-center max-w-full text-sm sm:text-base gap-0.5 xs:gap-1">
                    <span className="truncate">{t('waiting')}</span>
                    <span className="text-xs opacity-60 flex-shrink-0">({waitingGuests.length})</span>
                  </span>
                </button>
                
                {/* Animated Indicator */}
                <motion.div
                  className="absolute bottom-0 h-0.5 sm:h-1 bg-primary rounded-t-full"
                  style={isDragging ? {
                    left: activeTab === 'in-house' 
                      ? `${Math.max(0, Math.min(50, dragOffset * 100 + 0))}%`
                      : `${Math.max(0, Math.min(50, dragOffset * 100 + 50))}%`,
                    width: '50%'
                  } : undefined}
                  animate={!isDragging ? {
                    left: activeTab === 'in-house' ? '0%' : '50%',
                    width: '50%'
                  } : undefined}
                  transition={!isDragging ? {
                    type: 'spring',
                    stiffness: 400,
                    damping: 30,
                    duration: 0.15
                  } : undefined}
                />
              </div>
              
              {/* Departed Tab Button with Arrow */}
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setShowDepartedView(true);
                  setExpandedGuestId(null);
                }}
                className="h-11 px-2.5 xs:px-3 rounded-2xl flex items-center gap-1 flex-shrink-0 mr-2 transition-all"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Content with swipe */}
          <div 
            ref={containerRef}
            className="flex-1 overflow-hidden relative"
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            style={{ touchAction: swipeDirection === 'horizontal' ? 'none' : 'auto' }}
          >
            {/* Scrollable content area */}
            <div className="h-full overflow-y-auto">
              {isDragging && swipeDirection === 'horizontal' ? (
                // During drag: show current and adjacent tabs with slide effect
                <>
                  {/* Current tab */}
                  <div 
                    className="absolute inset-0 overflow-y-auto"
                    style={{ 
                      transform: `translateX(${dragOffset * 100}%)`,
                      transition: 'none',
                      pointerEvents: 'none'
                    }}
                  >
                    <div className="py-4 px-4 space-y-4">
                      {(activeTab === 'in-house' ? filterBySearch(inHouseGuests) : filterBySearch(waitingGuests)).length > 0 ? (
                        (activeTab === 'in-house' ? filterBySearch(inHouseGuests) : filterBySearch(waitingGuests)).map((guest) => (
                          <GuestCard 
                            key={guest.id} 
                            guest={guest}
                            onUpdateStatus={onUpdateGuestStatus}
                            onUpdateTransportation={onUpdateGuestTransportation}
                            onUpdateGuest={onUpdateGuest}
                            isExpanded={expandedGuestId === guest.id}
                            onExpandChange={handleExpandChange}
                          />
                        ))
                      ) : (
                        <div className="p-12 text-center text-muted-foreground">
                          {activeTab === 'in-house' ? t('noGuestsFound') : t('noWaitingGuests')}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Next tab (when swiping left) */}
                  {activeTab === 'in-house' && dragOffset < -0.02 && (
                    <div 
                      className="absolute inset-0 overflow-y-auto pointer-events-none"
                      style={{ 
                        transform: `translateX(${100 + dragOffset * 100}%)`,
                        transition: 'none'
                      }}
                    >
                      <div className="py-4 px-4 space-y-4">
                        {filterBySearch(waitingGuests).length > 0 ? (
                          filterBySearch(waitingGuests).map((guest) => (
                            <GuestCard 
                              key={guest.id} 
                              guest={guest}
                              onUpdateStatus={onUpdateGuestStatus}
                              onUpdateTransportation={onUpdateGuestTransportation}
                              onUpdateGuest={onUpdateGuest}
                              isExpanded={false}
                              onExpandChange={handleExpandChange}
                            />
                          ))
                        ) : (
                          <div className="p-12 text-center text-muted-foreground">
                            {t('noWaitingGuests')}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {/* Previous tab (when swiping right) */}
                  {activeTab === 'waiting' && dragOffset > 0.02 && (
                    <div 
                      className="absolute inset-0 overflow-y-auto pointer-events-none"
                      style={{ 
                        transform: `translateX(${-100 + dragOffset * 100}%)`,
                        transition: 'none'
                      }}
                    >
                      <div className="py-4 px-4 space-y-4">
                        {filterBySearch(inHouseGuests).length > 0 ? (
                          filterBySearch(inHouseGuests).map((guest) => (
                            <GuestCard 
                              key={guest.id} 
                              guest={guest}
                              onUpdateStatus={onUpdateGuestStatus}
                              onUpdateTransportation={onUpdateGuestTransportation}
                              onUpdateGuest={onUpdateGuest}
                              isExpanded={false}
                              onExpandChange={handleExpandChange}
                            />
                          ))
                        ) : (
                          <div className="p-12 text-center text-muted-foreground">
                            {t('noGuestsFound')}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </>
              ) : (
                // When not dragging: show current tab with smooth transition
                <motion.div 
                  key={activeTab}
                  className="absolute inset-0 overflow-y-auto"
                  initial={false}
                  animate={{ 
                    x: `${dragOffset * 100}%`,
                    opacity: 1
                  }}
                  transition={{ 
                    type: 'spring',
                    stiffness: 300,
                    damping: 30,
                    duration: 0.25
                  }}
                >
                  <div className="py-4 px-4 space-y-4">
                    {(activeTab === 'in-house' ? filterBySearch(inHouseGuests) : filterBySearch(waitingGuests)).length > 0 ? (
                      (activeTab === 'in-house' ? filterBySearch(inHouseGuests) : filterBySearch(waitingGuests)).map((guest) => (
                        <GuestCard 
                          key={guest.id} 
                          guest={guest}
                          onUpdateStatus={onUpdateGuestStatus}
                          onUpdateTransportation={onUpdateGuestTransportation}
                          onUpdateGuest={onUpdateGuest}
                          isExpanded={expandedGuestId === guest.id}
                          onExpandChange={handleExpandChange}
                        />
                      ))
                    ) : (
                      <div className="p-12 text-center text-muted-foreground">
                        {activeTab === 'in-house' ? t('noGuestsFound') : t('noWaitingGuests')}
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>

        {/* Departed Sheet */}
        <div
          className="absolute inset-0 flex flex-col bg-background transition-transform duration-300 ease-out"
          style={{
            transform: showDepartedView ? 'translateX(0)' : 'translateX(100%)'
          }}
        >
          {/* Tab Header for Departed */}
          <div className="flex-shrink-0 border-b border-border bg-card">
            <div className="flex items-center relative">
              {/* Back Button with Arrow */}
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setShowDepartedView(false);
                  setExpandedGuestId(null);
                }}
                className="h-11 px-2.5 xs:px-3 rounded-2xl flex items-center gap-1 flex-shrink-0 ml-2 transition-all"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>

              <div className="flex-1 flex px-2 xs:px-4 sm:px-6 relative">
                <button
                  className="flex-1 px-1 xs:px-2 sm:px-4 py-3 relative transition-all duration-300 flex items-center justify-center min-w-0 text-foreground font-semibold"
                >
                  <span className="relative z-10 flex items-center justify-center max-w-full text-sm sm:text-base gap-0.5 xs:gap-1">
                    <span className="truncate">{t('departed')}</span>
                    <span className="text-xs opacity-60 flex-shrink-0">({departedGuests.length})</span>
                  </span>
                </button>
                
                {/* Animated Indicator */}
                <div className="absolute bottom-0 h-0.5 sm:h-1 bg-primary rounded-t-full left-0 right-0" />
              </div>
            </div>
          </div>

          {/* Departed Content */}
          <div className="flex-1 overflow-hidden relative">
            <div className="h-full overflow-y-auto">
              <div className="py-4 px-4 space-y-4">
                {filterBySearch(departedGuests).length > 0 ? (
                  filterBySearch(departedGuests).map((guest) => (
                    <GuestCard 
                      key={guest.id} 
                      guest={guest}
                      onUpdateStatus={onUpdateGuestStatus}
                      onUpdateTransportation={onUpdateGuestTransportation}
                      onUpdateGuest={onUpdateGuest}
                      isExpanded={expandedGuestId === guest.id}
                      onExpandChange={handleExpandChange}
                    />
                  ))
                ) : (
                  <div className="p-12 text-center text-muted-foreground">
                    {t('noDepartedGuests')}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}