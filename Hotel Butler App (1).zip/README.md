
  # Hotel Butler App

  This is a code bundle for Hotel Butler App. The original project is available at https://www.figma.com/design/hcsZePBdGexHRGt0QoJpFw/Hotel-Butler-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  